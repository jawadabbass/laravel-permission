<?php

return [
    'route_middleware' => 'auth',
    'route_prefix' => 'admin',
    'route_name' => 'admin.',
    'route_domain' => null,
    'guard' => null,
];
